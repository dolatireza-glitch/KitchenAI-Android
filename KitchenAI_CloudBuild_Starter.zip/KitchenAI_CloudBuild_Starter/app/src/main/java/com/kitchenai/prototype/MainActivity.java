package com.kitchenai.prototype;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 101;
    private static final int REQ_GALLERY = 102;
    private FrameLayout photoFrame;
    private ImageView photoView;
    private TextView status;
    private EditText widthInput, heightInput, ceilingInput;
    private Spinner utilitySpinner;
    private final ArrayList<Marker> markers = new ArrayList<>();
    private Bitmap currentBitmap;
    private String selectedUtility = "Outlet / پریز";

    static class Marker {
        float x, y;
        String type;
        Marker(float x, float y, String type) { this.x=x; this.y=y; this.type=type; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text, int size) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size);
        t.setTextColor(Color.rgb(32, 40, 48)); t.setPadding(dp(2), dp(6), dp(2), dp(6)); return t;
    }
    private Button button(String text, Runnable r) {
        Button b = new Button(this); b.setText(text); b.setOnClickListener(v -> r.run()); return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.setBackgroundColor(Color.rgb(247, 248, 250));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = label("KITCHEN AI", 26);
        title.setTypeface(null, 1); root.addView(title);
        root.addView(label("Smart kitchen survey • Android prototype 0.1", 14));
        TextView note = label("Prototype: photo + dimensions + utility markers. AI auto-detection is not connected yet.", 13);
        note.setBackgroundColor(Color.rgb(255, 239, 205)); note.setPadding(dp(10),dp(10),dp(10),dp(10)); root.addView(note);

        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(button("Take photo", this::takePhoto), new LinearLayout.LayoutParams(0, dp(52), 1));
        row.addView(button("Choose photo", this::choosePhoto), new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(row);

        photoFrame = new FrameLayout(this);
        photoFrame.setBackgroundColor(Color.rgb(226,230,234));
        photoView = new ImageView(this); photoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        photoFrame.addView(photoView, new FrameLayout.LayoutParams(-1, dp(300)));
        photoFrame.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(300)));
        photoFrame.setOnTouchListener((v, e) -> {
            if (e.getAction() == android.view.MotionEvent.ACTION_UP && currentBitmap != null) {
                float x = e.getX() / Math.max(1f, v.getWidth());
                float y = e.getY() / Math.max(1f, v.getHeight());
                markers.add(new Marker(x,y,selectedUtility)); redrawPhoto(); updateStatus();
                return true;
            }
            return true;
        });
        root.addView(photoFrame);

        root.addView(label("Tap the photo to place a utility marker", 14));
        String[] utilities = {"Outlet / پریز", "Switch / کلید", "Cold water / آب سرد", "Hot water / آب گرم", "Gas / گاز", "Wall drain / درین دیوار", "Floor drain / درین کف", "Window / پنجره", "Door / در"};
        utilitySpinner = new Spinner(this);
        utilitySpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, utilities));
        utilitySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { selectedUtility=utilities[pos]; }
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
        root.addView(utilitySpinner);

        root.addView(label("Room dimensions (cm)", 18));
        widthInput = field("Wall width, e.g. 320");
        heightInput = field("Wall height, e.g. 245");
        ceilingInput = field("Ceiling height, e.g. 250");
        root.addView(widthInput); root.addView(heightInput); root.addView(ceilingInput);
        root.addView(button("Save survey summary", this::saveSummary));
        root.addView(button("Undo last marker", () -> {
            if (!markers.isEmpty()) { markers.remove(markers.size()-1); redrawPhoto(); updateStatus(); }
        }));
        status = label("No photo selected. Start by taking or choosing a photo.", 14);
        root.addView(status);
    }

    private EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(dp(8), dp(4), dp(8), dp(4)); return e;
    }

    private void takePhoto() {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, REQ_CAMERA);
        else Toast.makeText(this, "No camera app found", Toast.LENGTH_LONG).show();
    }
    private void choosePhoto() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*");
        startActivityForResult(Intent.createChooser(i, "Choose kitchen photo"), REQ_GALLERY);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        try {
            if (requestCode == REQ_CAMERA) {
                Object extra = data.getExtras() != null ? data.getExtras().get("data") : null;
                if (extra instanceof Bitmap) currentBitmap = (Bitmap) extra;
            } else if (requestCode == REQ_GALLERY) {
                Uri uri = data.getData();
                if (uri != null) {
                    InputStream in = getContentResolver().openInputStream(uri);
                    currentBitmap = BitmapFactory.decodeStream(in);
                    if (in != null) in.close();
                }
            }
            markers.clear(); redrawPhoto(); updateStatus();
        } catch (Exception ex) {
            Toast.makeText(this, "Could not load photo: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void redrawPhoto() {
        if (currentBitmap == null) { photoView.setImageDrawable(null); return; }
        Bitmap copy = currentBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(copy);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(Math.max(18, copy.getWidth()/28f)); p.setStrokeWidth(Math.max(3, copy.getWidth()/180f));
        for (int i=0;i<markers.size();i++) {
            Marker m=markers.get(i); float x=m.x*copy.getWidth(), y=m.y*copy.getHeight();
            p.setColor(Color.rgb(220,45,45)); p.setStyle(Paint.Style.STROKE); c.drawCircle(x,y,p.getTextSize()*0.75f,p);
            p.setStyle(Paint.Style.FILL); c.drawText((i+1)+". "+shortName(m.type), x+p.getTextSize(), y, p);
        }
        photoView.setImageBitmap(copy);
    }
    private String shortName(String s) {
        if (s.startsWith("Outlet")) return "Outlet";
        if (s.startsWith("Switch")) return "Switch";
        if (s.startsWith("Cold")) return "Cold water";
        if (s.startsWith("Hot")) return "Hot water";
        if (s.startsWith("Wall")) return "Wall drain";
        if (s.startsWith("Floor")) return "Floor drain";
        return s.split(" / ")[0];
    }
    private void updateStatus() {
        status.setText(String.format(Locale.US, "Photo: %s • Markers placed: %d • Floor drain height should be 0 cm (confirm on site).",
                currentBitmap == null ? "none" : "loaded", markers.size()));
    }
    private void saveSummary() {
        String w=widthInput.getText().toString(), h=heightInput.getText().toString(), c=ceilingInput.getText().toString();
        String summary="Kitchen AI survey summary\nWall width (cm): "+w+"\nWall height (cm): "+h+
                "\nCeiling height (cm): "+c+"\nMarkers: "+markers.size()+
                "\n\nThis prototype does not automatically detect utilities or validate dimensions.";
        Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT,"Kitchen AI survey summary"); send.putExtra(Intent.EXTRA_TEXT,summary);
        startActivity(Intent.createChooser(send,"Share survey summary"));
    }
}
